package connection;

public class DBConnection {
	public static final String DRIVER = "com.mysql.jdbc.Driver";  
	/*public static final String URL = "jdbc:mysql://127.7.223.130/casesdb";
	public static final String USERNAME = "adminTXjRpHK";
	public static final String PASSWORD = "vbQdMSjrPnFw"*/;
	public static final String URL = "jdbc:mysql://localhost/casesdb";
	public static final String USERNAME = "root";
	public static final String PASSWORD = "1234";
}