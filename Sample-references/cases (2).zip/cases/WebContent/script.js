function showBack() {
    window.history.back();
}
function showNext() {
	window.history.forward();
}
function goHome() {
	window.location.href = "index.jsp";
}
function goAdminHome() {
	window.location.href = "adminHome.jsp";
}
function goUserHome() {
	window.location.href = "userHome.jsp";
}
function mainHome() {
	window.location.href = "logout.jsp";
}